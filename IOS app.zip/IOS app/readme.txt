FoodnFriends is an app which recommends some good restaurants to users and their online friends. 
Based on iOS system, Users can chat with friends online and ask friends to join you for dinner.
Many functions of this app has been accomplished.